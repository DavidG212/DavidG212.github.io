//David Garcia
//CS 300
//6-17-2022

#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <vector>

using namespace std;

//Define course structure
struct Course {
	string courseNumber;
	string courseName;
	vector<string> prerequisites;
};

//A function that serparates strings based on the info gathered
vector<string> tokenize(string s, string del = " ") {
	vector<string> stringArray;
	int start = 0;
	int end = s.find(del);
	while (end  != -1) {
		stringArray.push_back(s.substr(start, end - start));
		start = end + del.size();
		end = s.find(del, start);
	}
	stringArray.push_back(s.substr(start, end - start));
	return stringArray;
 }

//Function that loads the read courses into the vector
vector<Course> loadCourses() {
	ifstream myFile;
	string readLine;
	vector<Course> courses;

	myFile.open("ABCU_Advising_Program_Input.txt");
	if (!myFile) {
		cout << "File could not be opened" << endl;
	}
	while (!myFile.eof()) {
		getline(myFile, readLine);
		Course course;
		vector<string> tokenizedInformation = tokenize(readLine, ",");
		course.courseNumber = tokenizedInformation[0];
		course.courseName = tokenizedInformation[1];
		for (int i = 0; i < tokenizedInformation.size(); i++) {
			course.prerequisites.push_back(tokenizedInformation[i]);
		}
		courses.push_back(course);
	}
	myFile.close();

	return courses;
}

//Function to print specific course info
void printCourseInformation(Course course) {
	string courseNumber = course.courseNumber;
	string courseName = course.courseName;
	vector<string> prerequisites = course.prerequisites;

	cout << course.courseNumber << ", " << course.courseName << endl;
	cout << "\n";
}

//Funciton to print the whole course list
void printCourseList(vector<Course> courses) {
	int n = courses.size();

	for (int i = 0; i < n - 1; i++) {
		for (int j = 0; j < n - 1 - i; j++) {
			if (courses[j].courseNumber > courses[j + 1].courseNumber) {
				swap(courses[j + 1], courses[j]);
			}
		}
	}
	for (int i = 0; i < n; i++) {
		printCourseInformation(courses[i]);
	}
}

//Function that helps search for specific course
void searchCourse(vector<Course> courses) {
	int n = courses.size();
	int c = 0;
	string courseNumber;

	cout << "Please enter the course number you are looking for.";
	cin >> courseNumber;
	for (int i = 0; i < n; i++) {
		if (courses[i].courseNumber == courseNumber) {
			c = 1;
			printCourseInformation(courses[i]);
			break;
		}
	}
	if (c == 0) {
		cout << "Course not found" << "\n";
	}
}


int main() {
	vector<Course> courses;
	int userChoice;

	//Do While loop to keep it going until Exit is chosen
	do {
		//Display menu options
		cout << "1. Load Data Structure" << endl;
		cout << "2. Print Course List" << endl;
		cout << "3. Print Course Information" << endl;
		cout << "4. Exit" << endl;
		cout << "Enter your choice: " << endl;
		cin >> userChoice;
		//switch cases to utilize menu choices 
		switch (userChoice) {
		case 1:
			courses = loadCourses();
			break;

		case 2:
			printCourseList(courses);
			break;

		case 3:
			searchCourse(courses);
			break;

		case 4:
			cout << "Exiting..." << endl;
			break;

		default:
			cout << "Invalid menu choice." << endl;
			break;
		}
	} while (userChoice != 4);
	return 0;
}