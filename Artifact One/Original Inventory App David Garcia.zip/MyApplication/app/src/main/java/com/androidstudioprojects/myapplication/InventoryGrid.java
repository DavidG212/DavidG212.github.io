package com.androidstudioprojects.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class InventoryGrid extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_grid);
    }
}