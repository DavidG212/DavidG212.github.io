package com.androidstudioprojects.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    //Declare Login variables
    EditText Username, Password;
    TextView loginView, usernameView, passwordView;
    Button signUpButton, loginButton;
    LoginDatabase db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Username = findViewById(R.id.Username);
        Password = findViewById(R.id.Password);
        loginButton = findViewById(R.id.loginButton);
        signUpButton = findViewById(R.id.signUpButton);
        db = new LoginDatabase(this);

        //Listener for loginButton
        loginButton.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = Username.getText().toString();
                String password = Password.getText().toString();

                if (username == null || password == null)
                    Toast.makeText(LoginActivity.this, "Enter a Username and Password", Toast.LENGTH_SHORT).show();
                else {
                    Boolean checkfields = db.checkUsernamePassword(username, password);
                    if (checkfields == true) {
                        Toast.makeText(LoginActivity.this, "Signed in!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), InventoryGrid.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(LoginActivity.this, "Invalid Username or Password", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }));
    }
}