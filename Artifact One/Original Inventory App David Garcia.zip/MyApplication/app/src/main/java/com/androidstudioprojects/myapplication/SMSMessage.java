package com.androidstudioprojects.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SMSMessage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_message);
    }
}