package com.androidstudioprojects.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SMSMessage extends AppCompatActivity {

    //onCreate method that saves instance state
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_message);
    }
}