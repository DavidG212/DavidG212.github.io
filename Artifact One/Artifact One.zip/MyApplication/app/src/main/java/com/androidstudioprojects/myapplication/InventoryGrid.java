/*
* CS 499 Capstone
* David Garcia
* 09/22/2023
*/
package com.androidstudioprojects.myapplication;

//import appcompat library and bundle library
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

//inventory grid class
public class InventoryGrid extends AppCompatActivity {

    //onCreate method that saves instance state
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_grid);
    }
}