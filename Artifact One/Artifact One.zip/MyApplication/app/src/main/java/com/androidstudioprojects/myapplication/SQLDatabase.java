package com.androidstudioprojects.myapplication;

//import libraries
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class SQLDatabase extends SQLiteOpenHelper {

    private static final String DB_NAME = "SQLdb.db";
    private static final int VERSION = 1;

    //Table for user phone numbers
    public static final class PhoneTable {
        private static final String TABLE = "phonenumbers";
        private static final String COL_ID = "_id";
        private static final String COL_PHONE_NUMBER = "PhoneNumbers";
    }

    //Table for inventory items
    public static final class InventoryItemsTable {
        private static final String TABLE = "inventory";
        private static final String COL_ID = "_id";
        private static final String COL_ITEM ="Item";
        private static final String COL_AMOUNT = "Amount";
    }

    //This will hold item information
    public class Items {
        public int id;
        public String name;
        public int amount;

        public Items(int id, String name, int amount) {
            this.id = id;
            this.name = name;
            this.amount = amount;
        }
    }

    public SQLDatabase(Context context) {

        super(context, DB_NAME, null, VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        //Create phone number table
        db.execSQL("create table " +
                PhoneTable.TABLE + " (" +
                PhoneTable.COL_ID + " integer," +
                PhoneTable.COL_PHONE_NUMBER + " text)");

        //Create inventory table
        db.execSQL("create table " +
                InventoryItemsTable.TABLE + " (" +
                InventoryItemsTable.COL_ID + " integer primary key autoincrement, " +
                InventoryItemsTable.COL_ITEM + " text, " +
                InventoryItemsTable.COL_AMOUNT + " integer)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    //Method to add items to inventory db
    public long addItem(String name, int amount) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InventoryItemsTable.COL_ITEM, name);
        values.put(InventoryItemsTable.COL_AMOUNT, amount);
        long insert = db.insert(InventoryItemsTable.TABLE, null, values);
        return insert;
    }

    //Method to retrieve the inventory from db
    public ArrayList<Items> getInventory() {

        ArrayList<Items> inventoryList = new ArrayList<Items>();
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "Select * from " +InventoryItemsTable.TABLE;
        Cursor cursor = db.rawQuery(sql, null);

        if (cursor.moveToFirst()) {
            do {
                int itemID = cursor.getInt(0);
                String itemName = cursor.getString(1);
                int itemAmount = cursor.getInt(2);
                Items newItem = new Items(itemID, itemName, itemAmount);

                inventoryList.add(newItem);
            }
            while (cursor.moveToNext());
        }
        cursor.close();
        return inventoryList;
    }

    //Method to delete an item from grid
    public boolean deleteItem(int id) {

        SQLiteDatabase db = this.getWritableDatabase();

        int rowsDeleted = db.delete(InventoryItemsTable.TABLE,
                InventoryItemsTable.COL_ID + " = ?",
                new String[] {Integer.toString(id)});
        return rowsDeleted > 0;
    }

    //Method to update an item
    public boolean updateItem(int id, int amount) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(InventoryItemsTable.COL_AMOUNT, amount);

        int rowsUpdated = db.update(InventoryItemsTable.TABLE, values,
                InventoryItemsTable.COL_ID + " =?",
                new String[] {Integer.toString(id)});
        return rowsUpdated > 0;
    }

    //Method to sign up a phone number for SMS messages
    public long assignTextNumber(String textNumber) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(PhoneTable.COL_ID, 1);
        values.put(PhoneTable.COL_PHONE_NUMBER, textNumber);

        long insert = db.insert(PhoneTable.TABLE, null, values);
        return insert;
    }
}
