package com.androidstudioprojects.myapplication;

//import libraries
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

//LoginDatabase class
public class LoginDatabase extends SQLiteOpenHelper {
    //Declare logindb string variable
    private static final String LOGINDB_NAME = "Login.db";
    public LoginDatabase(Context context) {
        super(context, LOGINDB_NAME, null, 1);
    }

    //onCreate method that creates db table
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table users(Username TEXT primary key, Password TEXT)");
    }

    //onUpgrade method that updates a db table
    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("drop table if exists users");
    }

    //addData method to add user data to db
    public boolean addData(String Username, String Password) {
        //Assign db and values
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        //Put user's Username and Password into values
        values.put("Username", Username);
        values.put("Password", Password);

        //Assign result to inserted users Username and Password
        long result = db.insert("users", null, values);
        return result != -1;
    }

    //Method to check username and password
    public boolean checkUsernamePassword(String Username, String Password) {
        //Assign db to getWritableDatabase
        SQLiteDatabase db = this.getWritableDatabase();

        //Assign cursor to db rawQuery which check Username and Password against existing data
        Cursor cursor = db.rawQuery("Select * from users where Username = ? and Password = ?", new String[] {Username, Password});

        //if cursor count is greater than 0, return true
        if(cursor.getCount() > 0) {
            return true;
        }
        else {
            return false;
        }
    }
}
