package com.androidstudioprojects.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginSignUpActivity extends AppCompatActivity {

    //Declare variables
    EditText Username, Password;
    Button  loginButton, signUpButton;
    LoginDatabase db;

    //onCreate method that contains save instance state
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //Declare Username, Password, loginButton, signupButton and db variables
        Username = findViewById(R.id.Username);
        Password = findViewById(R.id.Password);
        loginButton = findViewById(R.id.loginButton);
        signUpButton = findViewById(R.id.signUpButton);
        db = new LoginDatabase(this);

        //Listener for sign up button
        signUpButton.setOnClickListener(new View.OnClickListener() {

            //onClick method that executes on user click
            @Override
            public void onClick(View view) {
                ////on click grab entered Username and Password
                String username = Username.getText().toString();
                String password = Password.getText().toString();

                boolean checkUsernamePassword = db.checkUsernamePassword(username, password);

                //if fields are null ask user to enter both username and password
                if (username.equals("") || password.equals("")) {
                    Toast.makeText(LoginSignUpActivity.this, "Enter a Username and Password", Toast.LENGTH_SHORT).show();
                }
                //if checkUsernamePassword is false insert username and password into db
                if(!checkUsernamePassword){
                    boolean insert = db.addData(username, password);
                    //if inserted print that the user was registered
                    if(insert){
                        Toast.makeText(LoginSignUpActivity.this, "Registered successfully", Toast.LENGTH_SHORT).show();
                        //After registration go into inventory screen
                        Intent InventoryGridIntent = new Intent(LoginSignUpActivity.this, InventoryGrid.class);
                        startActivity(InventoryGridIntent);
                        //else print registration failed
                    } else{
                        Toast.makeText(LoginSignUpActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
                    }
                }
                //if user exists print that user already exists
                else{
                    Toast.makeText(LoginSignUpActivity.this, "User already exists! Please sign in", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //Listener for loginButton
        loginButton.setOnClickListener(new View.OnClickListener() {
            //onClick method that executes on user click
            @Override
            public void onClick(View view) {
                //on click grab entered Username and Password
                String username = Username.getText().toString();
                String password = Password.getText().toString();

                boolean checkUsernamePassword = db.checkUsernamePassword(username, password);

                //if fields are null ask user to enter both username and password, else check input against db
                if (username.equals("") || password.equals("")) {
                    Toast.makeText(LoginSignUpActivity.this, "Enter a Username and Password", Toast.LENGTH_SHORT).show();
                }
                //if checkUsernamePassword is true sign in user
                if (checkUsernamePassword) {
                    Toast.makeText(LoginSignUpActivity.this, "Signed in!", Toast.LENGTH_SHORT).show();
                    //After signin go into inventory screen
                    Intent InventoryGridIntent = new Intent(LoginSignUpActivity.this, InventoryGrid.class);
                    startActivity(InventoryGridIntent);
                    //else print that username/password was invalid
                } else {
                    Toast.makeText(LoginSignUpActivity.this, "Invalid Username or Password", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}